-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "postgis" WITH SCHEMA "public";

-- CreateExtension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- CreateEnum
CREATE TYPE "Language" AS ENUM ('ES', 'EN', 'IT', 'CA', 'FR', 'DE');

-- CreateEnum
CREATE TYPE "UserRole" AS ENUM ('ADMIN', 'ORGANIZER', 'ATHLETE', 'VIEWER');

-- CreateEnum
CREATE TYPE "RaceType" AS ENUM ('TRAIL', 'ULTRA', 'VERTICAL', 'SKYRUNNING', 'CANICROSS', 'OTHER');

-- CreateEnum
CREATE TYPE "EventStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "EditionStatus" AS ENUM ('UPCOMING', 'REGISTRATION_OPEN', 'REGISTRATION_CLOSED', 'ONGOING', 'FINISHED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "RegistrationStatus" AS ENUM ('NOT_OPEN', 'OPEN', 'FULL', 'CLOSED');

-- CreateEnum
CREATE TYPE "ParticipationStatus" AS ENUM ('INTERESTED', 'REGISTERED', 'CONFIRMED', 'COMPLETED', 'DNS', 'DNF', 'DSQ');

-- CreateEnum
CREATE TYPE "TranslationStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'NEEDS_REVIEW');

-- CreateEnum
CREATE TYPE "PostCategory" AS ENUM ('GENERAL', 'TRAINING', 'NUTRITION', 'GEAR', 'DESTINATIONS', 'INTERVIEWS', 'RACE_REPORTS', 'TIPS');

-- CreateEnum
CREATE TYPE "PostStatus" AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "username" VARCHAR(50) NOT NULL,
    "password" VARCHAR(255) NOT NULL,
    "firstName" VARCHAR(100),
    "lastName" VARCHAR(100),
    "role" "UserRole" NOT NULL DEFAULT 'ATHLETE',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "avatar" TEXT,
    "bio" TEXT,
    "phone" VARCHAR(20),
    "city" VARCHAR(100),
    "country" VARCHAR(2),
    "language" "Language" NOT NULL DEFAULT 'ES',
    "lastLoginAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "refresh_tokens" (
    "id" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "events" (
    "id" TEXT NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "country" VARCHAR(2) NOT NULL,
    "city" VARCHAR(100) NOT NULL,
    "location" geography(Point, 4326),
    "latitude" DECIMAL(10,8),
    "longitude" DECIMAL(11,8),
    "websiteUrl" TEXT,
    "email" VARCHAR(255),
    "phone" VARCHAR(20),
    "facebookUrl" TEXT,
    "instagramUrl" TEXT,
    "logo" TEXT,
    "coverImage" TEXT,
    "images" TEXT[],
    "firstEditionYear" INTEGER,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "isHighlighted" BOOLEAN NOT NULL DEFAULT false,
    "viewCount" INTEGER NOT NULL DEFAULT 0,
    "originalLanguage" "Language" NOT NULL DEFAULT 'ES',
    "status" "EventStatus" NOT NULL DEFAULT 'DRAFT',
    "organizerId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "events_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event_translations" (
    "id" TEXT NOT NULL,
    "eventId" TEXT NOT NULL,
    "language" "Language" NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "status" "TranslationStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "event_translations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "competitions" (
    "id" TEXT NOT NULL,
    "eventId" TEXT NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "shortName" VARCHAR(50),
    "description" TEXT,
    "type" "RaceType" NOT NULL DEFAULT 'TRAIL',
    "baseDistance" DECIMAL(6,2),
    "baseElevation" INTEGER,
    "baseMaxParticipants" INTEGER,
    "baseTechnicalLevel" SMALLINT,
    "websiteUrl" TEXT,
    "displayOrder" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "competitions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "competition_translations" (
    "id" TEXT NOT NULL,
    "competitionId" TEXT NOT NULL,
    "language" "Language" NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "shortName" VARCHAR(50),
    "description" TEXT,
    "status" "TranslationStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "competition_translations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "editions" (
    "id" TEXT NOT NULL,
    "competitionId" TEXT NOT NULL,
    "year" INTEGER NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "distance" DECIMAL(6,2),
    "elevation" INTEGER,
    "technicalLevel" SMALLINT,
    "startDate" TIMESTAMP(3) NOT NULL,
    "startTime" VARCHAR(10),
    "cutoffTime" VARCHAR(10),
    "city" VARCHAR(100),
    "location" geography(Point, 4326),
    "latitude" DECIMAL(10,8),
    "longitude" DECIMAL(11,8),
    "gpxFile" TEXT,
    "elevationProfile" TEXT,
    "routeDescription" TEXT,
    "routeMap" TEXT,
    "maxParticipants" INTEGER,
    "currentParticipants" INTEGER NOT NULL DEFAULT 0,
    "minimumAge" INTEGER DEFAULT 18,
    "price" DECIMAL(10,2),
    "currency" VARCHAR(3) DEFAULT 'EUR',
    "earlyBirdPrice" DECIMAL(10,2),
    "earlyBirdDeadline" TIMESTAMP(3),
    "registrationUrl" TEXT,
    "registrationStatus" "RegistrationStatus" NOT NULL DEFAULT 'NOT_OPEN',
    "status" "EditionStatus" NOT NULL DEFAULT 'UPCOMING',
    "isCancelled" BOOLEAN NOT NULL DEFAULT false,
    "cancellationReason" TEXT,
    "finishers" INTEGER,
    "dnfCount" INTEGER,
    "dnsCount" INTEGER,
    "dsqCount" INTEGER,
    "winnerTime" VARCHAR(20),
    "recordTime" VARCHAR(20),
    "recordHolder" VARCHAR(255),
    "averageTime" VARCHAR(20),
    "featuredImage" TEXT,
    "images" TEXT[],
    "videoUrl" TEXT,
    "viewCount" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "editions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "edition_translations" (
    "id" TEXT NOT NULL,
    "editionId" TEXT NOT NULL,
    "language" "Language" NOT NULL,
    "routeDescription" TEXT,
    "cancellationReason" TEXT,
    "status" "TranslationStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "edition_translations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_editions" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "editionId" TEXT NOT NULL,
    "status" "ParticipationStatus" NOT NULL DEFAULT 'INTERESTED',
    "bibNumber" VARCHAR(20),
    "position" INTEGER,
    "categoryName" VARCHAR(50),
    "categoryRank" INTEGER,
    "time" VARCHAR(20),
    "pace" VARCHAR(20),
    "notes" TEXT,
    "rating" SMALLINT,
    "wouldRepeat" BOOLEAN,
    "photos" TEXT[],
    "certificateUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "user_editions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "participants" (
    "id" TEXT NOT NULL,
    "editionId" TEXT NOT NULL,
    "userId" TEXT,
    "firstName" VARCHAR(100),
    "lastName" VARCHAR(100),
    "email" VARCHAR(255),
    "bibNumber" VARCHAR(20),
    "category" VARCHAR(50),
    "team" VARCHAR(100),
    "status" "ParticipationStatus" NOT NULL DEFAULT 'REGISTERED',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "participants_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "results" (
    "id" TEXT NOT NULL,
    "editionId" TEXT NOT NULL,
    "userId" TEXT,
    "bibNumber" VARCHAR(20),
    "firstName" VARCHAR(100),
    "lastName" VARCHAR(100),
    "position" INTEGER,
    "category" VARCHAR(50),
    "categoryRank" INTEGER,
    "time" VARCHAR(20),
    "timeSeconds" INTEGER,
    "pace" VARCHAR(20),
    "checkpoint1" VARCHAR(20),
    "checkpoint2" VARCHAR(20),
    "checkpoint3" VARCHAR(20),
    "checkpoint4" VARCHAR(20),
    "status" "ParticipationStatus" NOT NULL DEFAULT 'COMPLETED',
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "results_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reviews" (
    "id" TEXT NOT NULL,
    "editionId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "rating" SMALLINT NOT NULL,
    "comment" TEXT,
    "organization" SMALLINT,
    "route" SMALLINT,
    "atmosphere" SMALLINT,
    "valueForMoney" SMALLINT,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "reviews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "posts" (
    "id" TEXT NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "excerpt" TEXT,
    "content" TEXT NOT NULL,
    "featuredImage" TEXT,
    "category" "PostCategory" NOT NULL DEFAULT 'GENERAL',
    "status" "PostStatus" NOT NULL DEFAULT 'DRAFT',
    "editionId" TEXT,
    "authorId" TEXT NOT NULL,
    "viewCount" INTEGER NOT NULL DEFAULT 0,
    "publishedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "posts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "post_translations" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "language" "Language" NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "excerpt" TEXT,
    "content" TEXT NOT NULL,
    "status" "TranslationStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "post_translations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "post_tags" (
    "id" TEXT NOT NULL,
    "name" VARCHAR(50) NOT NULL,
    "slug" VARCHAR(50) NOT NULL,

    CONSTRAINT "post_tags_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_PostToPostTag" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE UNIQUE INDEX "refresh_tokens_token_key" ON "refresh_tokens"("token");

-- CreateIndex
CREATE INDEX "refresh_tokens_userId_idx" ON "refresh_tokens"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "events_slug_key" ON "events"("slug");

-- CreateIndex
CREATE INDEX "events_slug_idx" ON "events"("slug");

-- CreateIndex
CREATE INDEX "events_country_idx" ON "events"("country");

-- CreateIndex
CREATE INDEX "events_status_idx" ON "events"("status");

-- CreateIndex
CREATE INDEX "events_organizerId_idx" ON "events"("organizerId");

-- CreateIndex
CREATE INDEX "event_translations_eventId_idx" ON "event_translations"("eventId");

-- CreateIndex
CREATE UNIQUE INDEX "event_translations_eventId_language_key" ON "event_translations"("eventId", "language");

-- CreateIndex
CREATE UNIQUE INDEX "competitions_slug_key" ON "competitions"("slug");

-- CreateIndex
CREATE INDEX "competitions_eventId_idx" ON "competitions"("eventId");

-- CreateIndex
CREATE INDEX "competitions_slug_idx" ON "competitions"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "competitions_eventId_slug_key" ON "competitions"("eventId", "slug");

-- CreateIndex
CREATE INDEX "competition_translations_competitionId_idx" ON "competition_translations"("competitionId");

-- CreateIndex
CREATE UNIQUE INDEX "competition_translations_competitionId_language_key" ON "competition_translations"("competitionId", "language");

-- CreateIndex
CREATE UNIQUE INDEX "editions_slug_key" ON "editions"("slug");

-- CreateIndex
CREATE INDEX "editions_competitionId_idx" ON "editions"("competitionId");

-- CreateIndex
CREATE INDEX "editions_year_idx" ON "editions"("year");

-- CreateIndex
CREATE INDEX "editions_startDate_idx" ON "editions"("startDate");

-- CreateIndex
CREATE INDEX "editions_status_idx" ON "editions"("status");

-- CreateIndex
CREATE INDEX "editions_slug_idx" ON "editions"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "editions_competitionId_year_key" ON "editions"("competitionId", "year");

-- CreateIndex
CREATE INDEX "edition_translations_editionId_idx" ON "edition_translations"("editionId");

-- CreateIndex
CREATE UNIQUE INDEX "edition_translations_editionId_language_key" ON "edition_translations"("editionId", "language");

-- CreateIndex
CREATE INDEX "user_editions_userId_idx" ON "user_editions"("userId");

-- CreateIndex
CREATE INDEX "user_editions_editionId_idx" ON "user_editions"("editionId");

-- CreateIndex
CREATE UNIQUE INDEX "user_editions_userId_editionId_key" ON "user_editions"("userId", "editionId");

-- CreateIndex
CREATE INDEX "participants_editionId_idx" ON "participants"("editionId");

-- CreateIndex
CREATE INDEX "participants_userId_idx" ON "participants"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "participants_editionId_bibNumber_key" ON "participants"("editionId", "bibNumber");

-- CreateIndex
CREATE INDEX "results_editionId_idx" ON "results"("editionId");

-- CreateIndex
CREATE INDEX "results_userId_idx" ON "results"("userId");

-- CreateIndex
CREATE INDEX "results_position_idx" ON "results"("position");

-- CreateIndex
CREATE UNIQUE INDEX "results_editionId_bibNumber_key" ON "results"("editionId", "bibNumber");

-- CreateIndex
CREATE INDEX "reviews_editionId_idx" ON "reviews"("editionId");

-- CreateIndex
CREATE INDEX "reviews_userId_idx" ON "reviews"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "reviews_editionId_userId_key" ON "reviews"("editionId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "posts_slug_key" ON "posts"("slug");

-- CreateIndex
CREATE INDEX "posts_slug_idx" ON "posts"("slug");

-- CreateIndex
CREATE INDEX "posts_status_idx" ON "posts"("status");

-- CreateIndex
CREATE INDEX "posts_category_idx" ON "posts"("category");

-- CreateIndex
CREATE INDEX "posts_authorId_idx" ON "posts"("authorId");

-- CreateIndex
CREATE INDEX "posts_editionId_idx" ON "posts"("editionId");

-- CreateIndex
CREATE INDEX "post_translations_postId_idx" ON "post_translations"("postId");

-- CreateIndex
CREATE UNIQUE INDEX "post_translations_postId_language_key" ON "post_translations"("postId", "language");

-- CreateIndex
CREATE UNIQUE INDEX "post_tags_name_key" ON "post_tags"("name");

-- CreateIndex
CREATE UNIQUE INDEX "post_tags_slug_key" ON "post_tags"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "_PostToPostTag_AB_unique" ON "_PostToPostTag"("A", "B");

-- CreateIndex
CREATE INDEX "_PostToPostTag_B_index" ON "_PostToPostTag"("B");

-- AddForeignKey
ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "events" ADD CONSTRAINT "events_organizerId_fkey" FOREIGN KEY ("organizerId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_translations" ADD CONSTRAINT "event_translations_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "competitions" ADD CONSTRAINT "competitions_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES "events"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "competition_translations" ADD CONSTRAINT "competition_translations_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "editions" ADD CONSTRAINT "editions_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "edition_translations" ADD CONSTRAINT "edition_translations_editionId_fkey" FOREIGN KEY ("editionId") REFERENCES "editions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_editions" ADD CONSTRAINT "user_editions_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_editions" ADD CONSTRAINT "user_editions_editionId_fkey" FOREIGN KEY ("editionId") REFERENCES "editions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "participants" ADD CONSTRAINT "participants_editionId_fkey" FOREIGN KEY ("editionId") REFERENCES "editions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "participants" ADD CONSTRAINT "participants_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "results" ADD CONSTRAINT "results_editionId_fkey" FOREIGN KEY ("editionId") REFERENCES "editions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "results" ADD CONSTRAINT "results_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_editionId_fkey" FOREIGN KEY ("editionId") REFERENCES "editions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "posts" ADD CONSTRAINT "posts_editionId_fkey" FOREIGN KEY ("editionId") REFERENCES "editions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "posts" ADD CONSTRAINT "posts_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "post_translations" ADD CONSTRAINT "post_translations_postId_fkey" FOREIGN KEY ("postId") REFERENCES "posts"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_PostToPostTag" ADD CONSTRAINT "_PostToPostTag_A_fkey" FOREIGN KEY ("A") REFERENCES "posts"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_PostToPostTag" ADD CONSTRAINT "_PostToPostTag_B_fkey" FOREIGN KEY ("B") REFERENCES "post_tags"("id") ON DELETE CASCADE ON UPDATE CASCADE;
