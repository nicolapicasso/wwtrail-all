-- AlterTable
ALTER TABLE "events" ADD COLUMN     "typicalMonth" INTEGER;
