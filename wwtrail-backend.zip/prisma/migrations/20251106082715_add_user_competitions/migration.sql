/*
  Warnings:

  - You are about to drop the column `shortName` on the `competition_translations` table. All the data in the column will be lost.
  - You are about to drop the column `baseTechnicalLevel` on the `competitions` table. All the data in the column will be lost.
  - You are about to drop the column `displayOrder` on the `competitions` table. All the data in the column will be lost.
  - You are about to drop the column `isActive` on the `competitions` table. All the data in the column will be lost.
  - You are about to drop the column `shortName` on the `competitions` table. All the data in the column will be lost.
  - You are about to drop the column `websiteUrl` on the `competitions` table. All the data in the column will be lost.
  - You are about to alter the column `baseDistance` on the `competitions` table. The data in that column could be lost. The data in that column will be cast from `Decimal(6,2)` to `DoublePrecision`.
  - You are about to drop the column `averageTime` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `cancellationReason` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `currency` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `cutoffTime` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `dnfCount` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `dnsCount` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `dsqCount` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `earlyBirdDeadline` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `earlyBirdPrice` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `elevationProfile` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `featuredImage` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `finishers` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `gpxFile` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `images` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `isCancelled` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `latitude` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `longitude` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `minimumAge` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `price` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `recordHolder` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `recordTime` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `routeDescription` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `routeMap` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `startTime` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `technicalLevel` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `videoUrl` on the `editions` table. All the data in the column will be lost.
  - You are about to drop the column `winnerTime` on the `editions` table. All the data in the column will be lost.
  - You are about to alter the column `distance` on the `editions` table. The data in that column could be lost. The data in that column will be cast from `Decimal(6,2)` to `DoublePrecision`.
  - You are about to drop the column `facebookUrl` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `images` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `instagramUrl` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `isActive` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `isHighlighted` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `latitude` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `longitude` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `originalLanguage` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `websiteUrl` on the `events` table. All the data in the column will be lost.
  - You are about to drop the column `category` on the `participants` table. All the data in the column will be lost.
  - You are about to drop the column `editionId` on the `participants` table. All the data in the column will be lost.
  - You are about to drop the column `status` on the `participants` table. All the data in the column will be lost.
  - You are about to drop the column `team` on the `participants` table. All the data in the column will be lost.
  - You are about to alter the column `token` on the `refresh_tokens` table. The data in that column could be lost. The data in that column will be cast from `Text` to `VarChar(500)`.
  - You are about to drop the column `category` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `categoryRank` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `checkpoint1` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `checkpoint2` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `checkpoint3` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `checkpoint4` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `editionId` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `firstName` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `isVerified` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `lastName` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `pace` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `time` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `timeSeconds` on the `results` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `results` table. All the data in the column will be lost.
  - The `status` column on the `results` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - You are about to drop the column `atmosphere` on the `reviews` table. All the data in the column will be lost.
  - You are about to drop the column `editionId` on the `reviews` table. All the data in the column will be lost.
  - You are about to drop the column `isVerified` on the `reviews` table. All the data in the column will be lost.
  - You are about to drop the column `organization` on the `reviews` table. All the data in the column will be lost.
  - You are about to drop the column `route` on the `reviews` table. All the data in the column will be lost.
  - You are about to drop the column `valueForMoney` on the `reviews` table. All the data in the column will be lost.
  - You are about to drop the column `categoryName` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `categoryRank` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `certificateUrl` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `pace` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `photos` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `rating` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `time` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the column `wouldRepeat` on the `user_editions` table. All the data in the column will be lost.
  - You are about to drop the `edition_translations` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `event_translations` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[participantId]` on the table `results` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[competitionId,userId]` on the table `reviews` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `organizerId` to the `competitions` table without a default value. This is not possible if the table is not empty.
  - Made the column `firstEditionYear` on table `events` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `competitionId` to the `participants` table without a default value. This is not possible if the table is not empty.
  - Made the column `firstName` on table `participants` required. This step will fail if there are existing NULL values in that column.
  - Made the column `lastName` on table `participants` required. This step will fail if there are existing NULL values in that column.
  - Made the column `bibNumber` on table `participants` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `competitionId` to the `results` table without a default value. This is not possible if the table is not empty.
  - Added the required column `finishTime` to the `results` table without a default value. This is not possible if the table is not empty.
  - Added the required column `finishTimeSeconds` to the `results` table without a default value. This is not possible if the table is not empty.
  - Added the required column `participantId` to the `results` table without a default value. This is not possible if the table is not empty.
  - Made the column `bibNumber` on table `results` required. This step will fail if there are existing NULL values in that column.
  - Made the column `position` on table `results` required. This step will fail if there are existing NULL values in that column.
  - Added the required column `competitionId` to the `reviews` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "edition_translations" DROP CONSTRAINT "edition_translations_editionId_fkey";

-- DropForeignKey
ALTER TABLE "event_translations" DROP CONSTRAINT "event_translations_eventId_fkey";

-- DropForeignKey
ALTER TABLE "participants" DROP CONSTRAINT "participants_editionId_fkey";

-- DropForeignKey
ALTER TABLE "results" DROP CONSTRAINT "results_editionId_fkey";

-- DropForeignKey
ALTER TABLE "results" DROP CONSTRAINT "results_userId_fkey";

-- DropForeignKey
ALTER TABLE "reviews" DROP CONSTRAINT "reviews_editionId_fkey";

-- DropIndex
DROP INDEX "competitions_eventId_slug_key";

-- DropIndex
DROP INDEX "competitions_slug_idx";

-- DropIndex
DROP INDEX "editions_slug_idx";

-- DropIndex
DROP INDEX "participants_editionId_bibNumber_key";

-- DropIndex
DROP INDEX "participants_editionId_idx";

-- DropIndex
DROP INDEX "results_editionId_bibNumber_key";

-- DropIndex
DROP INDEX "results_editionId_idx";

-- DropIndex
DROP INDEX "results_userId_idx";

-- DropIndex
DROP INDEX "reviews_editionId_idx";

-- DropIndex
DROP INDEX "reviews_editionId_userId_key";

-- AlterTable
ALTER TABLE "competition_translations" DROP COLUMN "shortName";

-- AlterTable
ALTER TABLE "competitions" DROP COLUMN "baseTechnicalLevel",
DROP COLUMN "displayOrder",
DROP COLUMN "isActive",
DROP COLUMN "shortName",
DROP COLUMN "websiteUrl",
ADD COLUMN     "featured" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "organizerId" TEXT NOT NULL,
ADD COLUMN     "status" "EventStatus" NOT NULL DEFAULT 'DRAFT',
ADD COLUMN     "viewCount" INTEGER NOT NULL DEFAULT 0,
ALTER COLUMN "baseDistance" SET DATA TYPE DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "editions" DROP COLUMN "averageTime",
DROP COLUMN "cancellationReason",
DROP COLUMN "currency",
DROP COLUMN "cutoffTime",
DROP COLUMN "dnfCount",
DROP COLUMN "dnsCount",
DROP COLUMN "dsqCount",
DROP COLUMN "earlyBirdDeadline",
DROP COLUMN "earlyBirdPrice",
DROP COLUMN "elevationProfile",
DROP COLUMN "featuredImage",
DROP COLUMN "finishers",
DROP COLUMN "gpxFile",
DROP COLUMN "images",
DROP COLUMN "isCancelled",
DROP COLUMN "latitude",
DROP COLUMN "longitude",
DROP COLUMN "minimumAge",
DROP COLUMN "price",
DROP COLUMN "recordHolder",
DROP COLUMN "recordTime",
DROP COLUMN "routeDescription",
DROP COLUMN "routeMap",
DROP COLUMN "startTime",
DROP COLUMN "technicalLevel",
DROP COLUMN "videoUrl",
DROP COLUMN "winnerTime",
ADD COLUMN     "endDate" TIMESTAMP(3),
ADD COLUMN     "featured" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "notes" TEXT,
ADD COLUMN     "prices" JSONB,
ADD COLUMN     "registrationCloseDate" TIMESTAMP(3),
ADD COLUMN     "registrationOpenDate" TIMESTAMP(3),
ADD COLUMN     "regulations" TEXT,
ALTER COLUMN "distance" SET DATA TYPE DOUBLE PRECISION;

-- AlterTable
ALTER TABLE "events" DROP COLUMN "facebookUrl",
DROP COLUMN "images",
DROP COLUMN "instagramUrl",
DROP COLUMN "isActive",
DROP COLUMN "isHighlighted",
DROP COLUMN "latitude",
DROP COLUMN "longitude",
DROP COLUMN "originalLanguage",
DROP COLUMN "websiteUrl",
ADD COLUMN     "featured" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "gallery" TEXT[],
ADD COLUMN     "website" TEXT,
ALTER COLUMN "firstEditionYear" SET NOT NULL;

-- AlterTable
ALTER TABLE "participants" DROP COLUMN "category",
DROP COLUMN "editionId",
DROP COLUMN "status",
DROP COLUMN "team",
ADD COLUMN     "categoryId" TEXT,
ADD COLUMN     "city" VARCHAR(100),
ADD COLUMN     "club" VARCHAR(255),
ADD COLUMN     "competitionId" TEXT NOT NULL,
ADD COLUMN     "country" VARCHAR(2),
ADD COLUMN     "emergencyContact" TEXT,
ADD COLUMN     "medicalInfo" TEXT,
ADD COLUMN     "phone" VARCHAR(20),
ADD COLUMN     "registeredAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ALTER COLUMN "firstName" SET NOT NULL,
ALTER COLUMN "lastName" SET NOT NULL,
ALTER COLUMN "bibNumber" SET NOT NULL;

-- AlterTable
ALTER TABLE "refresh_tokens" ALTER COLUMN "token" SET DATA TYPE VARCHAR(500);

-- AlterTable
ALTER TABLE "results" DROP COLUMN "category",
DROP COLUMN "categoryRank",
DROP COLUMN "checkpoint1",
DROP COLUMN "checkpoint2",
DROP COLUMN "checkpoint3",
DROP COLUMN "checkpoint4",
DROP COLUMN "editionId",
DROP COLUMN "firstName",
DROP COLUMN "isVerified",
DROP COLUMN "lastName",
DROP COLUMN "pace",
DROP COLUMN "time",
DROP COLUMN "timeSeconds",
DROP COLUMN "userId",
ADD COLUMN     "categoryId" TEXT,
ADD COLUMN     "categoryPosition" INTEGER,
ADD COLUMN     "competitionId" TEXT NOT NULL,
ADD COLUMN     "finishTime" VARCHAR(20) NOT NULL,
ADD COLUMN     "finishTimeSeconds" INTEGER NOT NULL,
ADD COLUMN     "participantId" TEXT NOT NULL,
ADD COLUMN     "splits" JSONB,
ALTER COLUMN "bibNumber" SET NOT NULL,
ALTER COLUMN "position" SET NOT NULL,
DROP COLUMN "status",
ADD COLUMN     "status" VARCHAR(20) NOT NULL DEFAULT 'COMPLETED';

-- AlterTable
ALTER TABLE "reviews" DROP COLUMN "atmosphere",
DROP COLUMN "editionId",
DROP COLUMN "isVerified",
DROP COLUMN "organization",
DROP COLUMN "route",
DROP COLUMN "valueForMoney",
ADD COLUMN     "competitionId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "user_editions" DROP COLUMN "categoryName",
DROP COLUMN "categoryRank",
DROP COLUMN "certificateUrl",
DROP COLUMN "pace",
DROP COLUMN "photos",
DROP COLUMN "rating",
DROP COLUMN "time",
DROP COLUMN "wouldRepeat",
ADD COLUMN     "categoryPosition" INTEGER,
ADD COLUMN     "completedAt" TIMESTAMP(3),
ADD COLUMN     "finishTime" TEXT,
ADD COLUMN     "finishTimeSeconds" INTEGER,
ADD COLUMN     "markedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "personalRating" SMALLINT;

-- DropTable
DROP TABLE "edition_translations";

-- DropTable
DROP TABLE "event_translations";

-- CreateTable
CREATE TABLE "user_competitions" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "competitionId" TEXT NOT NULL,
    "status" "ParticipationStatus" NOT NULL DEFAULT 'INTERESTED',
    "finishTime" TEXT,
    "finishTimeSeconds" INTEGER,
    "position" INTEGER,
    "categoryPosition" INTEGER,
    "notes" TEXT,
    "personalRating" SMALLINT,
    "completedAt" TIMESTAMP(3),
    "markedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "user_competitions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "categories" (
    "id" TEXT NOT NULL,
    "competitionId" TEXT NOT NULL,
    "name" VARCHAR(100) NOT NULL,
    "description" TEXT,
    "minAge" INTEGER,
    "maxAge" INTEGER,
    "gender" VARCHAR(1),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "favorites" (
    "id" TEXT NOT NULL,
    "competitionId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "favorites_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "files" (
    "id" TEXT NOT NULL,
    "filename" VARCHAR(255) NOT NULL,
    "originalName" VARCHAR(255) NOT NULL,
    "mimeType" VARCHAR(100) NOT NULL,
    "size" INTEGER NOT NULL,
    "path" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "uploaderId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "files_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notifications" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "type" VARCHAR(50) NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "message" TEXT NOT NULL,
    "data" JSONB,
    "read" BOOLEAN NOT NULL DEFAULT false,
    "readAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "notifications_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "user_competitions_userId_idx" ON "user_competitions"("userId");

-- CreateIndex
CREATE INDEX "user_competitions_competitionId_idx" ON "user_competitions"("competitionId");

-- CreateIndex
CREATE INDEX "user_competitions_status_idx" ON "user_competitions"("status");

-- CreateIndex
CREATE UNIQUE INDEX "user_competitions_userId_competitionId_key" ON "user_competitions"("userId", "competitionId");

-- CreateIndex
CREATE INDEX "categories_competitionId_idx" ON "categories"("competitionId");

-- CreateIndex
CREATE INDEX "favorites_competitionId_idx" ON "favorites"("competitionId");

-- CreateIndex
CREATE INDEX "favorites_userId_idx" ON "favorites"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "favorites_competitionId_userId_key" ON "favorites"("competitionId", "userId");

-- CreateIndex
CREATE INDEX "files_uploaderId_idx" ON "files"("uploaderId");

-- CreateIndex
CREATE INDEX "notifications_userId_idx" ON "notifications"("userId");

-- CreateIndex
CREATE INDEX "notifications_read_idx" ON "notifications"("read");

-- CreateIndex
CREATE INDEX "competitions_status_idx" ON "competitions"("status");

-- CreateIndex
CREATE INDEX "competitions_type_idx" ON "competitions"("type");

-- CreateIndex
CREATE INDEX "competitions_organizerId_idx" ON "competitions"("organizerId");

-- CreateIndex
CREATE INDEX "events_city_idx" ON "events"("city");

-- CreateIndex
CREATE INDEX "events_typicalMonth_idx" ON "events"("typicalMonth");

-- CreateIndex
CREATE INDEX "participants_competitionId_idx" ON "participants"("competitionId");

-- CreateIndex
CREATE INDEX "participants_categoryId_idx" ON "participants"("categoryId");

-- CreateIndex
CREATE INDEX "refresh_tokens_token_idx" ON "refresh_tokens"("token");

-- CreateIndex
CREATE UNIQUE INDEX "results_participantId_key" ON "results"("participantId");

-- CreateIndex
CREATE INDEX "results_competitionId_idx" ON "results"("competitionId");

-- CreateIndex
CREATE INDEX "results_categoryId_idx" ON "results"("categoryId");

-- CreateIndex
CREATE INDEX "reviews_competitionId_idx" ON "reviews"("competitionId");

-- CreateIndex
CREATE UNIQUE INDEX "reviews_competitionId_userId_key" ON "reviews"("competitionId", "userId");

-- CreateIndex
CREATE INDEX "user_editions_status_idx" ON "user_editions"("status");

-- CreateIndex
CREATE INDEX "users_email_idx" ON "users"("email");

-- CreateIndex
CREATE INDEX "users_username_idx" ON "users"("username");

-- CreateIndex
CREATE INDEX "users_role_idx" ON "users"("role");

-- AddForeignKey
ALTER TABLE "competitions" ADD CONSTRAINT "competitions_organizerId_fkey" FOREIGN KEY ("organizerId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_competitions" ADD CONSTRAINT "user_competitions_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_competitions" ADD CONSTRAINT "user_competitions_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "categories" ADD CONSTRAINT "categories_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "participants" ADD CONSTRAINT "participants_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "participants" ADD CONSTRAINT "participants_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "results" ADD CONSTRAINT "results_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "results" ADD CONSTRAINT "results_participantId_fkey" FOREIGN KEY ("participantId") REFERENCES "participants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "results" ADD CONSTRAINT "results_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "categories"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "favorites" ADD CONSTRAINT "favorites_competitionId_fkey" FOREIGN KEY ("competitionId") REFERENCES "competitions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "favorites" ADD CONSTRAINT "favorites_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "files" ADD CONSTRAINT "files_uploaderId_fkey" FOREIGN KEY ("uploaderId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notifications" ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
