# Handoff: Rediseño del portal WWTRAIL

## Overview
Rediseño moderno, usable y optimizado del portal **WWTRAIL** — una plataforma de descubrimiento de carreras de trail running (eventos, competiciones, circuitos/"special series", organizadores y un mapa mundial). El rediseño reorganiza la jerarquía visual, saca al frente los datos deportivos clave (distancia, desnivel, nº de carreras), corrige errores de contenido del portal original (texto con codificación rota, imágenes placeholder vacías) y unifica todo bajo un sistema visual coherente.

Cubre las pantallas clave:
1. **Home / landing**
2. **Listado de eventos** (con vista Grid/Lista)
3. **Detalle de evento**
4. **Special Series** (listado de circuitos)
5. **Organizadores** (listado + perfil de organizador)
6. **Mapa mundial** (con panel de filtros)
7. **Comunidad** (directorio de corredores)
8. **Ficha de usuario**
9. **Insiders** (directorio de embajadores)
10. **Ficha de Insider**

## About the Design Files
Los archivos de `prototypes/` son **referencias de diseño creadas en HTML** — prototipos que muestran el aspecto y el comportamiento previstos, **no son código de producción para copiar tal cual**. Están escritos como "Design Components" (`.dc.html`): HTML con estilos inline + una pequeña clase de lógica JS. Para abrirlos en el navegador necesitan el runtime `support.js` (incluido en la misma carpeta); también puedes leer su código fuente directamente como referencia.

**La tarea** es **recrear estos diseños en el entorno real del proyecto WWTRAIL** (el portal actual está hecho como SPA con contenido renderizado por JavaScript — probablemente React/Vue). Usa los patrones, componentes y librerías ya establecidos en el codebase. Si alguna parte del entorno aún no existe, elige el enfoque más apropiado y consistente con el resto del proyecto. No hay que desplegar el HTML directamente.

## Fidelity
**Alta fidelidad (hi-fi).** Colores, tipografía, espaciados, radios y estados están definidos y deben reproducirse con precisión, usando las librerías/componentes existentes del codebase. Las **fotografías** son placeholders (bloques con rayas diagonales y una etiqueta monoespaciada tipo `hero_photo.jpg — …`): en producción se sustituyen por las imágenes reales de cada evento/serie/organizador, respetando las proporciones y overlays indicados.

---

## Design Tokens

### Colores
| Token | Hex | Uso |
|---|---|---|
| `ink` | `#0f1315` | Nav, footer, texto sobre claro fuerte, fondos oscuros |
| `ink-2` | `#14181a` | Color de texto principal |
| `paper` | `#f4f3ee` | Fondo de página (blanco cálido) |
| `surface` | `#ffffff` | Tarjetas, paneles |
| `surface-alt` | `#f4f3ee` | Chips de stats, inputs, celdas internas |
| `border` | `#e6e4dd` | Bordes de tarjetas/inputs |
| `hairline` | `#eeece5` | Separadores internos (border-top de footers de card) |
| `text-muted` | `#6b6f70` | Texto secundario |
| `text-faint` | `#8b9295` | Labels, metadatos |
| `placeholder` | `#9a9e9f` | Texto de placeholders de input |
| `brand-green` | `#1f7a4d` | Color de acción primario (botones, links, CTA, activo) |
| `brand-green-bright` | `#2ea36a` | Logo, pins de mapa, avatar admin, acentos |
| `green-tint-bg` | `#e9f6ef` | Fondo de badges/chips verdes |
| `green-tint-border` | `#bfe6d1` | Borde de chips verdes |
| `accent-orange` | `#f0a05a` | Badge FEATURED, motivo de acento en hero |
| `accent-orange-strong` | `#d1631f` | Cifras de desnivel (elevación), links secundarios |
| `orange-text` | `#c2733a` | Labels de desnivel |
| `orange-tint-bg` | `#fdf1e7` | Fondo de chip de desnivel |

Acento de perfil de organizador: gradiente de banner `linear-gradient(105deg, #173f6e 0%, #1f7a4d 100%)`.
Fondo de mapa: `radial-gradient(circle at 45% 40%, #16505a, #0c222b)`; masas de tierra `#1f5e3d`; retícula `#4fd190` a baja opacidad.

### Tipografía
- **Familia UI / títulos:** `Archivo` (Google Fonts), pesos 400/500/600/700/800/900.
- **Familia de cifras deportivas:** `Barlow Semi Condensed` (Google Fonts), pesos 500/600/700. Se usa SOLO para números grandes (stats: distancia, desnivel, contadores, paginación).
- Antialiasing: `-webkit-font-smoothing: antialiased`.

Escala tipográfica observada:
| Rol | Tamaño | Peso | Notas |
|---|---|---|---|
| Hero H1 (home) | 64px | 900 | `letter-spacing:-0.03em; line-height:0.98` |
| Hero H1 (detalle/series) | 48–52px | 900 | `letter-spacing:-0.03em` |
| Título de sección | 28px | 900 | `letter-spacing:-0.02em` |
| Título de card interna | 22px | 900 | `letter-spacing:-0.01em` |
| Título de evento (card) | 18–19px | 800 | |
| Cuerpo | 15–16px | 400 | `line-height:1.6–1.7` |
| Metadatos / footers | 12.5–14px | 600 | |
| Labels (uppercase) | 10–11px | 700 | `letter-spacing:.08–.14em; text-transform:uppercase` |
| Cifra de stat | 22–34px | 700 | `Barlow Semi Condensed`, `line-height:1–1.05` |

### Espaciado y forma
- Ancho de contenido máx: **1360px** (mapa: 1600px), padding lateral **40px** (mapa/nav 32px).
- Altura de nav: **68px** (mapa 64px), sticky, `z-index:50`.
- Radios: tarjetas grandes **18px**, tarjetas de contenido **16px**, chips/inputs/botones **10–14px**, celdas de stat **10–12px**, pills **999px**.
- Gap de grids: **20–22px**. Grids de 3 columnas (`repeat(3,1fr)`).
- Sombra de card: `0 1px 2px rgba(20,24,26,.04)`. Sombra elevada (search hero): `0 12px 40px rgba(0,0,0,.35)`. Sombra flotante (controles de mapa/leyenda): `0 4px 16–20px rgba(0,0,0,.2–.25)`.

### Motivo topográfico
Líneas de contorno SVG (curvas horizontales apiladas) en verde `#2ea36a` a opacidad ~.10–.12 sobre fondos oscuros (hero home, hero eventos). En banners con gradiente (perfil organizador) las líneas son blancas a ~.15. En el mapa, retícula recta verde.

---

## Screens / Views

### 1. Home (`WWTRAIL Home.dc.html`)
**Propósito:** entrada al portal; buscar y descubrir.
**Layout (top→bottom):**
- **Nav** negro sticky (logo mountain-mark + menú: Eventos▾, Competiciones▾, Servicios, Mapa, Comunidad▾, Revista; a la derecha selector idioma 🌐 Español▾ y pill de usuario `admin`).
- **Hero** 560px, fondo oscuro con rayas diagonales + contornos topográficos + overlay degradado. Contiene: eyebrow naranja ("La plataforma para trail runners"), H1 64px "Toda carrera de montaña del mundo, en un solo lugar.", subtítulo, **barra de búsqueda** blanca (input + botón verde "Buscar"), fila de 3 stats (115 Eventos · 112 Ciudades · 21 Circuitos) en Barlow, y dots de carrusel abajo centrados.
- **Value props:** 3 tarjetas blancas (icono en cuadro tintado 46px, título 19px/800, descripción). Reescribe el contenido roto del original.
- **Eventos destacados:** header de sección + "Ver todos →"; grid 3× de *cards de evento* (ver componente Event Card).
- **Banda de mapa:** bloque redondeado 320px, fondo verde-azulado con retícula y pins, texto a la izquierda + botón blanco "Abrir mapa →".
- **Últimos eventos añadidos:** grid 3× de cards con descripción (variante con párrafo en vez de stats).
- **Revista:** grid 3× de cards de post (imagen con badge de categoría, título, resumen, autor + fecha).
- **Footer** negro: bloque de marca + 3 columnas de links (Explorar / Comunidad / Síguenos) + barra inferior de copyright.

### 2. Listado de eventos (`WWTRAIL Eventos.dc.html`)
**Propósito:** explorar/filtrar los 115 eventos.
**Layout:**
- Nav (Eventos activo).
- **Hero destacados** oscuro: eyebrow, H1 46px "Encuentra tu próxima montaña", subtítulo, y **bloque destacado asimétrico** = una card grande (1.55fr) + dos apiladas (1fr). La grande muestra ubicación, título 32px y 3 stats (Carreras / Distancia máx / Desnivel+ en naranja).
- **Toolbar:** título "Todos los eventos" + contador ("Mostrando 12 de 115 · página 1 de 10") a la izquierda; **segmented control Grid/Lista** a la derecha (fondo `#e7e5dd`, segmento activo blanco con sombra).
- **Barra de filtros** blanca: input de búsqueda (flex:1) + chips (País▾, Ciudad▾, Mes▾) + chip verde activo "★ Destacados▾".
- **Grid de cards** 3 columnas (o lista de 1 columna según el toggle).
- **Paginación** centrada: botones cuadrados 40px, activo verde relleno, resto con borde; con `‹`, números, `…`, y `›`.

### 3. Detalle de evento (`WWTRAIL Evento.dc.html`)
**Propósito:** ficha completa de un evento (ej. Gran Trail Courmayeur).
**Layout:**
- Nav.
- **Hero** 420px con foto (placeholder) + overlay; breadcrumb, badge "🏆 FEATURED", H1 52px, y fila de meta (📍 ciudad · 📅 mes · 🏆 nº competiciones · 🕑 años de historia).
- **Cuerpo en 2 columnas** `1fr / 380px`, `gap:28px`, `align-items:start`:
  - **Izquierda:** "Sobre el evento" (párrafo), "🏆 Competiciones" (lista de carreras; cada fila = cuadro con km en Barlow + nombre + meta distancia/desnivel/estado + flecha; hover: `border-color:#1f7a4d;background:#fbfdfb`), "Información detallada" (3 celdas: País / Ciudad / Primera edición).
  - **Derecha (sidebar sticky, top:88px):** tarjeta de logo/marca, tarjeta "📍 Ubicación" (mini-mapa placeholder + link "Ver en Google Maps"), "Estadísticas" (Visualizaciones / Competiciones / Años en Barlow), "Contacto y redes", "Eventos cercanos (5)" (links naranja), y **CTA verde** "☆ Guardar evento".

### 7–10. Comunidad, Ficha de usuario, Insiders, Ficha de Insider (`WWTRAIL Comunidad.dc.html`)
Cuatro vistas en un archivo, conmutadas por **pestañas** bajo el nav (sticky, top:68px): "Comunidad", "Ficha de usuario", "Insiders", "Ficha de Insider". Pestaña activa: verde con `border-bottom:3px solid #1f7a4d`.

**Decisión de tema:** en el portal original la comunidad/usuario usa un degradado azul→morado y los Insiders un naranja. En el rediseño se unifica bajo la paleta del sistema: **verde/azul-profundo para usuario normal**, **dorado/naranja como identidad Insider** (coherente con el badge existente).

- **Comunidad (directorio):** título con icono + subtítulo, barra de filtros (búsqueda de corredores, selector País, rango Edad mín/máx, toggle Grid/Lista), grid 3× de **cards de corredor**. Card de corredor = cabecera 120px con motivo topográfico (badge "★ INSIDER" naranja arriba-der si aplica) + avatar circular 84px con iniciales solapado (margin-top:-42px, borde blanco 4px) + nombre + @handle + "📍 ubicación" + fila de 3 stats (Finishes / Carreras / Edad en Barlow; Edad en naranja).
- **Ficha de usuario:** hero 300px con gradiente `linear-gradient(120deg,#173f6e,#1f7a4d)` + contornos blancos; link "← Volver" arriba-izq; avatar cuadrado 132px (radius 20px) con iniciales; H1 46px + badge "⭐ WWTrail Insider" (si aplica); @handle; meta (país · 📍 ciudad · género); y **3 stats grandes** a la derecha (Finishes / Carreras / DNF, Barlow 44px). Cuerpo 2 columnas `360px / 1fr`: izquierda tarjeta "Información" (filas Miembro desde / País / Ciudad con separadores) + (solo insider) tarjeta dorada de badge; derecha "Historial de carreras" con contador y **empty state** (🏆 grande atenuado + "No hay participaciones registradas" + CTA verde "Explorar carreras →").
- **Insiders (directorio):** hero 200px naranja/dorado `linear-gradient(105deg,#e8961f,#d1631f)` con marca (cuadro translúcido), H1 "WWTrail Insiders" y meta (👤 N Insiders · 🌐 N Países). Tarjeta de intro explicativa. Grid 3× de **cards de insider** = avatar circular 96px con iniciales + insignia ⭐ solapada (círculo naranja 34px, borde blanco) + nombre + @handle en naranja + "📍 ubicación".
- **Ficha de Insider:** misma estructura que Ficha de usuario pero con tema dorado/naranja (hero `linear-gradient(105deg,#e8961f,#d1631f)`, avatar en tono `#b9541a`) y la tarjeta destacada "⭐ WWTrail Insider" visible en el sidebar.

### 4 & 5. Special Series + Organizadores (`WWTRAIL Series y Organizadores.dc.html`)
Tres vistas en un archivo, conmutadas por **pestañas** bajo el nav (sticky, top:68px): "Special Series", "Organizadores", "Perfil de organizador". Pestaña activa: verde con `border-bottom:3px solid #1f7a4d`.
- **Special Series (listado):** título + subtítulo con contador (21), input de búsqueda, grid 3× de cards de serie. Card de serie = cabecera de color sólido (fondo por serie) con abreviatura grande en Barlow centrada + badge "🏆 N" arriba a la derecha; cuerpo con nombre + "🌐 idioma · N competiciones" + flecha.
- **Organizadores (listado):** título con icono, subtítulo con contador (46), fila de filtros (búsqueda + selector País), grid 3× de cards de organizador (avatar cuadrado con iniciales sobre color + nombre truncado + "📍 país · N eventos"), paginación.
- **Perfil de organizador:** banner con gradiente azul→verde + contornos blancos, avatar circular 132px con iniciales, badge "🏢 ORGANIZADOR", H1 48px, ubicación. Cuerpo 2 columnas `1fr/360px`: izquierda "Sobre el organizador" + "📅 Eventos organizados (N)" (cada evento = cabecera con avatar+nombre+lugar+badge nº, y grid 2× de carreras con etiqueta TRAIL + nombre + km); derecha sidebar sticky (top:130px) con "Contacto y redes" y "Estadísticas".

### 6. Mapa (`WWTRAIL Mapa.dc.html`)
**Propósito:** exploración geográfica con filtros.
**Layout:** nav (64px) + área flex a pantalla completa:
- **Sidebar** 340px, blanca, scroll: título, "Tipo de ítem" (grid 2× de toggles; "Todos" activo verde), "Buscar", "País" (select), "Distancia (km)" (Desde/Hasta), "Desnivel positivo (m)" (Desde/Hasta), "Tipos de terreno" (checkboxes; el marcado usa cuadro verde con ✓), y acciones "Aplicar filtros" (verde) + "Limpiar".
- **Mapa** flex:1, fondo oscuro con retícula + masas de tierra estilizadas; controles de zoom `+/−` arriba-izquierda, botón "🗺 Terreno" arriba-derecha, **pins** tipo gota (verde normal, naranja destacado), y **tarjeta-leyenda** abajo-izquierda con contador ("115 carreras en el mapa") + leyenda de colores.
> En producción el mapa es **Leaflet** (el portal actual usa Leaflet con tiles Esri/OpenTopoMap). El diseño del panel, pins, controles y leyenda debe aplicarse sobre el Leaflet real; el fondo estilizado del prototipo es solo representativo.

---

## Componente reutilizable: Event Card
- Contenedor: `background:#fff; border:1px solid #e6e4dd; border-radius:16px; overflow:hidden; box-shadow:0 1px 2px rgba(20,24,26,.04)`.
- **Media** (170–190px): imagen (placeholder rayado) + overlay inferior `linear-gradient(180deg, transparent 45%, rgba(15,19,21,.55))`; chip de tag arriba-izq (blanco), badge de mes arriba-der (pill oscuro translúcido), y ubicación "📍 …" abajo-izq en blanco con text-shadow. Variante destacada: añade badge "★ FEATURED" naranja.
- **Cuerpo** (padding 18px): título 18–19px/800; **fila de 3 chips de stat** (Carreras / Dist. máx / Desnivel+); footer con `border-top:1px solid #eeece5` → "Desde AÑO · 🌐 Web" + link "Ver detalle →" verde/800.
- **Chip de stat:** `flex:1; border-radius:10px; padding:10px 12px`. Neutro = fondo `#f4f3ee`. Desnivel = fondo `#fdf1e7`, label `#c2733a`, cifra `#d1631f`. Label 10px/700 uppercase; cifra en Barlow 22px/700 con sufijo (km/m) pequeño y atenuado.
- **Modo lista:** contenedor `display:flex; align-items:stretch`; media pasa a `flex:0 0 300px; min-height:200px`; cuerpo `flex:1`.

## Interactions & Behavior
- **Nav:** sticky arriba; items con submenús (▾) en Eventos, Competiciones, Comunidad.
- **Toggle Grid/Lista** (listado de eventos): cambia el layout del grid (3 columnas ↔ 1 columna) y la disposición interna de cada card (bloque ↔ fila con media de 300px). Estado local.
- **Pestañas** (Series/Organizadores): cambian la vista mostrada; estado local; pestaña activa con subrayado verde.
- **Hover en filas de competición** (detalle de evento): borde verde + fondo `#fbfdfb`.
- **CTA "Guardar evento":** acción de guardar/favorito (pendiente de backend).
- **Búsqueda y filtros:** en producción, filtran los resultados (país, ciudad, mes, destacados; distancia/desnivel/terreno en el mapa).
- **Mapa:** zoom, cambio de capa (Terreno), pins clicables → popup/ficha; leyenda refleja el recuento filtrado.
- **Transiciones:** usar transiciones suaves y discretas en hover/estado (color y borde). No hay animaciones complejas especificadas.

## State Management
- `view: 'grid' | 'list'` — modo del listado de eventos.
- `screen: 'series' | 'list' | 'profile'` — vista activa en Series/Organizadores.
- `screen: 'dir' | 'user' | 'insiders' | 'insider'` — vista activa en Comunidad.
- Filtros de comunidad: query de búsqueda, país, rango de edad; flag `insider` por corredor.
- Estado de filtros por pantalla (query de búsqueda, país, ciudad, mes, destacado; rangos de distancia/desnivel y terrenos en el mapa).
- Datos por fetch desde la API existente del portal: eventos, competiciones/carreras, special series, organizadores, geolocalizaciones para el mapa. Paginación en listados (eventos ~10 páginas; organizadores 4 páginas).

## Assets
- **Fuentes:** Google Fonts — `Archivo` y `Barlow Semi Condensed`.
- **Logo:** mountain-mark en SVG inline (triángulo de montaña relleno verde `#2ea36a` con trazo blanco); ver `<svg>` en la cabecera de cualquier prototipo. Reutiliza el logo oficial de WWTRAIL si existe en el codebase.
- **Iconografía:** en los prototipos se usan emojis como marcadores de posición (📍 🏆 🔍 🌐 📅 🕑 ⛰ 🏔). **En producción, sustituir por el set de iconos del codebase** (line icons monocromáticos). No son parte del sistema final.
- **Imágenes:** placeholders rayados con etiqueta → reemplazar por fotos reales de eventos/series/organizadores. Overlays y proporciones según cada pantalla.
- **Mapa:** Leaflet (tiles Esri satélite / OpenTopoMap, como el portal actual).

## Files
En `prototypes/`:
- `WWTRAIL Home.dc.html` — Home / landing
- `WWTRAIL Eventos.dc.html` — Listado de eventos (Grid/Lista)
- `WWTRAIL Evento.dc.html` — Detalle de evento
- `WWTRAIL Series y Organizadores.dc.html` — Special Series + Organizadores (listado + perfil)
- `WWTRAIL Mapa.dc.html` — Mapa mundial con filtros
- `WWTRAIL Comunidad.dc.html` — Comunidad + Ficha de usuario + Insiders + Ficha de Insider (4 vistas)
- `support.js` — runtime necesario para abrir los `.dc.html` en el navegador

**Cómo usarlos:** ábrelos en un navegador (necesitan `support.js` en la misma carpeta) para ver el diseño, o lee su código fuente como referencia. Los estilos están inline y la lógica está en la clase `Component` al final de cada archivo.
