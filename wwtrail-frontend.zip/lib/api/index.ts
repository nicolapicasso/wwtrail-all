export { default as apiClient } from './client';
export { authService } from './auth.service';
export { competitionsService } from './competitions.service';
